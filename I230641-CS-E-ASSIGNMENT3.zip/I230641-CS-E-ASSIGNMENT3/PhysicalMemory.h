#pragma once
class PhysicalMemory {
private:
    int MyCapacity;

public:
    // Constructors
    PhysicalMemory(int theCap = 0) : MyCapacity(theCap) {}

    // Getters
    int getCapacity() const { return MyCapacity; }

    // Setters
    void setCapacity(int theCap) { MyCapacity = theCap; }
};
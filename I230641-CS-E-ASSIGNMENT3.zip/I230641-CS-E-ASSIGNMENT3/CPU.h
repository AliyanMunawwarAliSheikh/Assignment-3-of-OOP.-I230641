#pragma once
class CPU {
private:
    ALU myALU;
    ControlUnit myCU;

public:

    CPU() : myALU(0, 0, 0, 0), myCU(0.0f) {}


    CPU(int myAdders, int mySubtractors, int myRegisters, int mySize, float myClock)
        : myALU(myAdders, mySubtractors, myRegisters, mySize), myCU(myClock) {}


    ALU GetALU() const { return myALU; }
    void GetALU(const ALU& theALU) { myALU = theALU; }

    ControlUnit GetControlUnit() const { return myCU; }
    void SetControlUnit(const ControlUnit& theCU) { myCU = theCU; }
};
/*Aliyan Munawwar
CS-E
I23-0641
Ms.Marium Hida
Muhammad Ali Naveed
*/

#include<iostream>
using namespace std;
#include"ALU.h"
#include"ControlUnit.h"
#include"CPU.h"
#include"MainMemory.h"
#include"Port.h"
#include"MotherBoard.h"
#include"PhysicalMemory.h"
#include"Computer.h"
#include"GraphicsCard.h"
#include"StorageDevice.h"
#include"NetworkCard.h"
#include"PowerSupply.h"
#include"Battery.h"
#include"Case.h"
#include"ComputerAssembly.h"


int main() {

    string thePortType;
    int theRate;

    // Initialize variables
    float myPrice = 0.0;
    int checkDevice = 0;
    CPU myCPU;
    MotherBoard myMotherBoard;
    PhysicalMemory myPhysicalMemory;
    MainMemory myMainMemory;
    GraphicsCard myGraphicsCard;
    StorageDevice myStorageDevice;
    NetworkCard myNetworkCard;
    PowerSupply myPowerSupply;
    Battery myBattery;
    Case myCase;

    // Prompt user to choose a device
    cout << "Choose the Device : \n1)Computer\n2)Mac\n\nEnter 1 or 2 : ";
    do {
        cin >> checkDevice;
        if (checkDevice != 1 && checkDevice != 2) {
            cout << "Invalid Input\nTry Again\n";
        }
    } while (checkDevice != 1 && checkDevice != 2);

    // Inputs for CPU
    int theAdders, theSubtractors, theRegisters, theSize;
    do {
        cout << "Subtractors : ";
        cin >> theSubtractors;
        cout << "\nAdders : ";
        cin >> theAdders;
        cout << "RegisterSize(Bits): ";
        cin >> theSize;
        cout << "Registers";
        cin >> theRegisters;

        if (theAdders <= 0 || theSubtractors <= 0 || theRegisters <= 0 || theSize <= 0) {
            cout << "\nInvalid Input\nInput can't be 0 or less\nTry Again\n";
        }
    } while (theAdders <= 0 || theSubtractors <= 0 || theRegisters <= 0 || theSize <= 0);

    // Initialize ALU
    ALU alu(theAdders, theSubtractors, theRegisters, theSize);

    // Inputs for Control Unit
    float theClock;
    do {
        cout << "\nEnter clock speed (GHz): ";
        cin >> theClock;

        if (theClock <= 0) {
            cout << "\nInvalid Input\nInput can't be 0 or less\nTry Again\n";
        }
    } while (theClock <= 0);

    // Initialize Control Unit
    ControlUnit cu(theClock);

    int theCapacity;
    string theTechnology;
    Port thePort[10];
    int checkTechnology;

    // Inputs for Main Memory
    do {
        cout << "\nEnter capacity of main memory (Gb): ";
        cin >> theCapacity;
        if (theCapacity <= 0) {
            cout << "\nInvalid Input\nInput can't be 0 or less\nTry Again\n";
        }
    } while (theCapacity <= 0);

    // Inputs for Technology Type of Main Memory
    do {
        cout << "\nEnter technology type of main memory : \n1) Semiconductor\n2) Silicon\nEnter 1 or 2 : ";
        cin >> checkTechnology;
        if (checkTechnology == 1)
            theTechnology = "Semiconductor";
        else if (checkTechnology == 2)
            theTechnology = "Silicon";
        else
            cout << "Invalid Input\nTry Again\n";
    } while (checkTechnology != 1 && checkTechnology != 2);

    // Inputs for Ports
    for (int i = 0; i < 10; ++i) {
        int checkPort;
        do {
            cout << "\nEnter the type of port " << i + 1 << " for main memory : \n1) VGA Port\n2) I/O Port\n3) USB Port\n4) HDMI Port\nEnter 1, 2, 3, or 4: ";
            cin >> checkPort;
            if (checkPort < 1 || checkPort > 4) {
                cout << "\nInvalid Input\nPlease enter a number between 1 and 4\n";
            }
        } while (checkPort < 1 || checkPort > 4);

        // Initialize Port
        string thePortType;
        int theRate = 0;
        switch (checkPort) {
        case 1:
            thePortType = "VGA Port";
            theRate = 60;
            break;
        case 2:
            thePortType = "I/O Port";
            theRate = 120;
            break;
        case 3:
            thePortType = "USB Port";
            theRate = 30;
            break;
        case 4:
            thePortType = "HDMI Port";
            theRate = 30;
            break;
        default:
            cout << "\nInvalid Input\n";
            break;
        }

        // Store Port information
        thePort[i] = Port(thePortType, theRate);
    }

    // Initialize Motherboard with Main Memory and Ports


    myMotherBoard = MotherBoard(MainMemory(theCapacity, theTechnology), thePort);

    // Inputs for Physical Memory
    do {
        cout << "\nEnter capacity of physical memory (Gb): ";
        cin >> theCapacity;
        if (theCapacity <= 0) {
            cout << "\nInvalid Input\nInput can't be 0 or less\nTry Again\n";
        }
    } while (theCapacity <= 0);

    // Initialize Physical Memory
    myPhysicalMemory = PhysicalMemory(theCapacity);

    // Inputs for Graphics Card
    string theBrand;
    int theMemorySize;

    // Initialize Graphics Card
    double thePrice;
    int checkBrand;
    bool isValidBrand = false;
    while (!isValidBrand) {
        cout << "\nEnter brand of graphics card : \n1) Nvidia\n2) AMD\n3) AppleGPU\nEnter 1, 2, or 3: ";
        cin >> checkBrand;

        switch (checkBrand) {
        case 1: theBrand = "Nvidia";
            thePrice = 600;
        case 2: theBrand = "AMD";
            thePrice = 500;
        case 3: {
            theBrand = "AppleGPU";
            thePrice = 800;
        }
              isValidBrand = true;
              break;
        default:
            cout << "\nInvalid Input\nPlease enter 1, 2, or 3\n";
            break;
        }
    }

    // Handling default cases
    if (checkBrand == 1) {
        theBrand = "Nvidia";
        thePrice = 700;
    }
    else if (checkBrand == 2) {
        theBrand = "AMD";
        thePrice = 650;
    }
    else if (checkBrand == 3) {
        theBrand = "AppleGPU";
        thePrice = 900;
    }

    // Inputs for Graphics Card memory size
    bool isValidMemorySize = false;
    while (!isValidMemorySize) {
        cout << "\nEnter memory size of graphics card (Gb): ";
        cin >> theMemorySize;

        if (theMemorySize <= 0) {
            cout << "\nInvalid Input\nMemory size must be greater than 0\nTry Again\n";
        }
        else {
            isValidMemorySize = true;
        }
    }

    // Initialize Graphics Card
    myPrice += thePrice;
    myGraphicsCard = GraphicsCard(theBrand, theMemorySize, thePrice);

    // Inputs for Storage Device
    string theType;
    int checkStorage;
    bool isValidStorageType = false;
    while (!isValidStorageType) {
        cout << "\nEnter type of storage device : \n1) HDD\n2) SSD\nEnter 1 or 2: ";
        cin >> checkStorage;

        switch (checkStorage) {
        case 1:
            theType = "HDD";
            thePrice = 350;
            isValidStorageType = true;
            break;
        case 2:
            theType = "SSD";
            thePrice = 500;
            isValidStorageType = true;
            break;
        default:
            cout << "\nInvalid Input\nPlease enter 1 or 2\n";
            break;
        }
    }

    // Inputs for Storage Device capacity
    do {
        cout << "\nEnter capacity of storage device (Gb): ";
        cin >> theCapacity;
        if (theCapacity <= 0) {
            cout << "\nInvalid Input\nCapacity must be greater than 0\nTry Again\n";
        }
    } while (theCapacity <= 0);

    // Initialize Storage Device
    myPrice += thePrice;
    myStorageDevice = StorageDevice(theType, theCapacity, thePrice);

    // Inputs for Network Card
    int theSpeed;
    bool isValidType = false;
    while (!isValidType) {
        cout << "\nEnter type of network card : \n1) Ethernet\n2) WiFi\nEnter 1 or 2: ";
        int checkNetwork;
        cin >> checkNetwork;

        if (checkNetwork == 1) {
            theType = "Ethernet";
            isValidType = true;
        }
        else if (checkNetwork == 2) {
            theType = "WiFi";
            isValidType = true;
        }
        else {
            cout << "\nInvalid Input\nPlease enter 1 or 2\n";
        }
    }

    // Inputs for Network Card speed
    bool isValidSpeed = false;
    while (!isValidSpeed) {
        cout << "\nEnter speed of network card (Gb/sec): ";
        cin >> theSpeed;

        if (theSpeed <= 0) {
            cout << "\nInvalid Input\nSpeed must be greater than 0\nTry Again\n";
        }
        else {
            isValidSpeed = true;
        }
    }

    // Initialize Network Card
    thePrice = 500;
    myPrice += thePrice;
    myNetworkCard = NetworkCard(theType, theSpeed, thePrice);

    // Inputs for Power Supply
    string theEfficiencyRating;
    int theWattage;

    // Inputs for Power Supply wattage
    do {
        cout << "\nEnter wattage of power supply (W): ";
        cin >> theWattage;
        if (theWattage <= 0) {
            cout << "\nInvalid Input\nWattage can't be 0 or less\nTry Again\n";
        }
    } while (theWattage <= 0);

    // Inputs for Power Supply efficiency rating
    int checkEfficiency;
    bool isValidEfficiency = false;
    while (!isValidEfficiency) {
        cout << "\nEnter efficiency rating of power supply: \n1) 80 Plus Bronze\n2) 80 Plus Gold\nEnter 1 or 2: ";
        cin >> checkEfficiency;

        switch (checkEfficiency) {
        case 1:
            theEfficiencyRating = "80 Plus Bronze";
            thePrice = 150;
            isValidEfficiency = true;
            break;
        case 2:
            theEfficiencyRating = "80 Plus Gold";
            thePrice = 300;
            isValidEfficiency = true;
            break;
        default:
            cout << "\nInvalid Input\nPlease enter 1 or 2\n";
            break;
        }
    }

    // Initialize Power Supply
    myPrice += thePrice;
    myPowerSupply = PowerSupply(theWattage, theEfficiencyRating, thePrice);

    // Inputs for Battery (if applicable)
    if (checkDevice == 2) {
        bool isValidCapacity = false;
        while (!isValidCapacity) {
            cout << "\nEnter capacity of battery (mAh): ";
            cin >> theCapacity;
            if (theCapacity <= 0) {
                cout << "\nInvalid Input\nInput can't be 0 or less\nTry Again\n";
            }
            else {
                isValidCapacity = true;
            }
        }
        // Initialize Battery
        myBattery = Battery(theCapacity);
    }

    // Inputs for Case
    string theFormFactor, color;
    int checkFormFactor, checkColor;

    if (checkDevice == 1) {
        bool isValidFormFactor = false;
        while (!isValidFormFactor) {
            cout << "\nEnter form factor of case : \n1) ATX\n2) Micro ATX\nEnter 1 or 2 : ";
            cin >> checkFormFactor;
            if (checkFormFactor == 1) {
                theFormFactor = "ATX";
                thePrice = 100;
                isValidFormFactor = true;
            }
            else if (checkFormFactor == 2) {
                theFormFactor = "Micro ATX";
                thePrice = 80;
                isValidFormFactor = true;
            }
            else {
                cout << "Invalid Input\nTry Again\n";
            }
        }

        bool isValidColor = false;
        while (!isValidColor) {
            cout << "\nEnter color of the case that you prefer : \n1) Black\n2) White\nEnter 1 or 2 : ";
            cin >> checkColor;
            if (checkColor == 2) {
                color = "White";
                isValidColor = true;
            }
            else if (checkColor == 1) {
                color = "Black";
                isValidColor = true;
            }
            else {
                cout << "Invalid Input\nTry Again\n";
            }
        }
    }

    // Initialize Case
    myPrice += thePrice;
    myCase = Case(theFormFactor, color);
    myPrice += 1000;

    // Create Computer Assembly object
    ComputerAssembly computer;
    if (checkDevice == 1 || checkDevice == 2) {
        // Initialize Computer Assembly
        computer = ComputerAssembly(
            &myCPU,
            &myMainMemory,
            &myMotherBoard,
            &myGraphicsCard,
            &myStorageDevice,
            &myNetworkCard,
            &myPowerSupply,
            &myBattery,
            &myCase,
            myPrice
        );
    }

    return 0;
}

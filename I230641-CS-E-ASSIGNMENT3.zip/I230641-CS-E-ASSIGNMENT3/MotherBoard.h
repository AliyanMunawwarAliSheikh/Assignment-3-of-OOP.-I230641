#pragma once
class MotherBoard {
private:
    MainMemory MyMM;
    Port MyPorts[4]; // Maximum of 4 ports

public:
    // Constructors
    MotherBoard(const MainMemory& theMemory = MainMemory(), const Port* thePortsArray = nullptr) : MyMM(theMemory) {
        if (thePortsArray != nullptr) {
            for (int i = 0; i < 4; ++i) {
                MyPorts[i] = thePortsArray[i];
            }
        }
    }

    // Getters
    MainMemory& getMainMemory() { return MyMM; }
    const MainMemory& getMainMemory() const { return MyMM; }

    const Port* getPorts() const { return MyPorts; }

    // Setters
    void setMainMemory(const MainMemory& theMemory) { MyMM = theMemory; }
    void setPorts(const Port* thePortsArray) {
        if (thePortsArray != nullptr) {
            for (int i = 0; i < 4; ++i) {
                MyPorts[i] = thePortsArray[i];
            }
        }
    }
};
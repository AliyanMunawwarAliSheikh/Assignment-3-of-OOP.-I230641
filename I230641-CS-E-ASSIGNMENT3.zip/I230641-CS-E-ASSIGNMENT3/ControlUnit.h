#pragma once
class ControlUnit {
private:
    float myClock;

public:
    ControlUnit(float theMyClock = 0.0f) : myClock(theMyClock) {}

    // Getter
    float GetMyClock() const { return myClock; }

    // Setter
    void SetMyClock(float theMyClock) { myClock = theMyClock; }
};
#pragma once
class PowerSupply {
private:
    int MyWattage;
    string MyEfficiencyRating;
    double MyPrice;

public:
    // Constructors
    PowerSupply(int theWattage = 0, const string& theEfficiencyRating = "", double thePrice = 0.0)
        : MyWattage(theWattage), MyEfficiencyRating(theEfficiencyRating), MyPrice(thePrice) {}

    // Getters
    int getWattage() const { return MyWattage; }
    string getEfficiencyRating() const { return MyEfficiencyRating; }
    double getPrice() const { return MyPrice; }

    // Setters
    void setWattage(int theWattage) { MyWattage = theWattage; }
    void setEfficiencyRating(const string& theEfficiencyRating) { MyEfficiencyRating = theEfficiencyRating; }
    void setPrice(double thePrice) { MyPrice = thePrice; }
};
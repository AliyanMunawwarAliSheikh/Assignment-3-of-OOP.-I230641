#pragma once
class MainMemory {
private:
    int theCapacity;
    string theTechnologyType;

public:
    // Default constructor
    MainMemory() : theCapacity(0), theTechnologyType("Semiconductor") {}

    // Overloaded constructor
    MainMemory(int theCapacity, const string& theTechnologyType)
        : theCapacity(theCapacity), theTechnologyType(theTechnologyType) {}

    // Getter for theCapacity
    int GetTheCapacity() const {
        return theCapacity;
    }

    // Setter for theCapacity
    void SetTheCapacity(int theCapacity) {
        this->theCapacity = theCapacity;
    }

    // Getter for theTechnologyType
    string GetTheTechnologyType() const {
        return theTechnologyType;
    }

    // Setter for theTechnologyType
    void SetTheTechnologyType(const string& theTechnologyType) {
        this->theTechnologyType = theTechnologyType;
    }
};
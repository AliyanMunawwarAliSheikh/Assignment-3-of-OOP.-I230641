#pragma once
class StorageDevice {
private:
    string MyType;
    int MyCapacity;
    double MyPrice;

public:
    // Constructors
    StorageDevice(const string& theType = "", int theCapacity = 0, double thePrice = 0.0)
        : MyType(theType), MyCapacity(theCapacity), MyPrice(thePrice) {}

    // Getters
    string getType() const { return MyType; }
    int getCapacity() const { return MyCapacity; }
    double getPrice() const { return MyPrice; }

    // Setters
    void setType(const string& theType) { MyType = theType; }
    void setCapacity(int theCapacity) { MyCapacity = theCapacity; }
    void setPrice(double thePrice) { MyPrice = thePrice; }
};
#pragma once
class Port {
private:
    string myType;
    int myBaudRate;

public:
    // Default constructor initializing attributes with default parameters
    Port() : myType("VGI Port"), myBaudRate(9600) {}

    // Overloaded constructor initializing attributes with parameters
    Port(const string& theType, int theBaudRate)
        : myType(theType), myBaudRate(theBaudRate) {}

    string getMyType() const {
        return myType;
    }

    void setMyType(const string& theType) {
        myType = theType;
    }

    int GetMyBaudRate() const {
        return myBaudRate;
    }

    void SetMyBaudRate(int theBaudRate) {
        myBaudRate = theBaudRate;
    }
};
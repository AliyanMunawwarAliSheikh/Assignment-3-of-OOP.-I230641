#pragma once
class Battery {
private:
    int MyCapacity;

public:
    // Constructors
    Battery(int theCapacity = 0) : MyCapacity(theCapacity) {}

    // Getters
    int getCapacity() const { return MyCapacity; }

    // Setters
    void setCapacity(int theCapacity) { MyCapacity = theCapacity; }
};
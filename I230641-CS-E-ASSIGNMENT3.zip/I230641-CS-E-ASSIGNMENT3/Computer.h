#pragma once
class Computer {
private:
    PhysicalMemory* MyPM;
    MotherBoard* MyMB;
    CPU* MyCPU;

public:
    // Constructors
    Computer(PhysicalMemory* theMemory = nullptr, MotherBoard* theMotherboard = nullptr, CPU* theProcessor = nullptr)
        : MyPM(theMemory), MyMB(theMotherboard), MyCPU(theProcessor) {}

    // Destructor
    ~Computer() {
        delete MyPM;
        delete MyMB;
        delete MyCPU;
    }

    // Getters
    PhysicalMemory* getPhysicalMemory() const

    {
        return MyPM;
    }
    MotherBoard* getMotherBoard() const { return MyMB; }
    CPU* getCPU() const { return MyCPU; }

    // Setters
    void setPhysicalMemory(PhysicalMemory* theMemory) { MyPM = theMemory; }
    void setMotherBoard(MotherBoard* theMotherboard) { MyMB = theMotherboard; }
    void setCPU(CPU* theProcessor) { MyCPU = theProcessor; }
};
#pragma once
class NetworkCard {
private:
    string MyType;
    int MySpeed;
    double MyPrice;

public:
    // Constructors
    NetworkCard(const string& theType = "", int theSpeed = 0, double thePrice = 0.0)
        : MyType(theType), MySpeed(theSpeed), MyPrice(thePrice) {}

    // Getters
    string getType() const { return MyType; }
    int getSpeed() const { return MySpeed; }
    double getPrice() const { return MyPrice; }

    // Setters
    void setType(const string& theType) { MyType = theType; }
    void setSpeed(int theSpeed) { MySpeed = theSpeed; }
    void setPrice(double thePrice) { MyPrice = thePrice; }
};
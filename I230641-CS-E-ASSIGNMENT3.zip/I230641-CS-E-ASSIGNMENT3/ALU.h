#pragma once
class ALU {
private:
    int myNoOfAdders;
    int myNoOfSubtractors;
    int myNoOfRegisters;
    int mySizeOfRegisters;

public:
    ALU(int theAdders = 0, int theSubtractors = 0, int theRegisters = 0, int theRegSize = 0)
        : myNoOfAdders(theAdders), myNoOfSubtractors(theSubtractors), myNoOfRegisters(theRegisters), mySizeOfRegisters(theRegSize) {}

    // Getters
    int GetNoOfAdders() const { return myNoOfAdders; }
    int GetNoOfSubtractors() const { return myNoOfSubtractors; }
    int GetNoOfRegisters() const { return myNoOfRegisters; }
    int GetSizeOfRegisters() const { return mySizeOfRegisters; }

    // Setters
    void SetNoOfAdders(int theAdders) { myNoOfAdders = theAdders; }
    void SetNoOfSubtractors(int theSubtractors) { myNoOfSubtractors = theSubtractors; }
    void SetNoOfRegisters(int theRegisters) { myNoOfRegisters = theRegisters; }
    void SetSizeOfRegisters(int theRegSize) { mySizeOfRegisters = theRegSize; }
};
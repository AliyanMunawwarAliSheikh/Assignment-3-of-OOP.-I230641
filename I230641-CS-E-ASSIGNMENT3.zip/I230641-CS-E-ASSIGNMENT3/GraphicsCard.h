#pragma once
class GraphicsCard {
private:
    string MyBrand;
    int MyMemorySize;
    double MyPrice;

public:
    // Constructors
    GraphicsCard(const string& theBrand = "", int theSize = 0, double thePrice = 0.0)
        : MyBrand(theBrand), MyMemorySize(theSize), MyPrice(thePrice) {}

    // Getters
    string getMyBrand() const { return MyBrand; }
    int getmyMemorySize() const { return MyMemorySize; }
    double getMyPrice() const { return MyPrice; }

    // Setters
    void setMyBrand(const string& theBrand) { MyBrand = theBrand; }
    void setmyMemorySize(int theSize) { MyMemorySize = theSize; }
    void setMyPrice(double thePrice) { MyPrice = thePrice; }
};
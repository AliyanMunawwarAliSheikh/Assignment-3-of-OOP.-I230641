#pragma once
class Case {
private:
    string MyFormFactor;
    string MyColor;
    double MyPrice;

public:
    // Constructors
    Case(const string& theFormFactor = "", const string& theColor = "", double thePrice = 0.0)
        : MyFormFactor(theFormFactor), MyColor(theColor), MyPrice(thePrice) {}

    // Getters
    string getFormFactor() const { return MyFormFactor; }
    string getColor() const { return MyColor; }
    double getPrice() const { return MyPrice; }

    // Setters
    void setFormFactor(const string& theFormFactor) { MyFormFactor = theFormFactor; }
    void setColor(const string& theColor) { MyColor = theColor; }
    void setPrice(double thePrice) { MyPrice = thePrice; }
};
#pragma once
class ComputerAssembly {
private:
    CPU* myCPU;
    MainMemory* myMainMemory;
    MotherBoard* myMotherBoard;
    GraphicsCard* myGraphicsCard;
    StorageDevice* myStorageDevice;
    NetworkCard* myNetworkCard;
    PowerSupply* myPowerSupply;
    Battery* myBattery;
    Case* myCase;
    double totalPrice;

public:
    // Constructors
    ComputerAssembly()
        : myCPU(nullptr), myMainMemory(nullptr), myMotherBoard(nullptr), myGraphicsCard(nullptr),
        myStorageDevice(nullptr), myNetworkCard(nullptr), myPowerSupply(nullptr), myBattery(nullptr),
        myCase(nullptr), totalPrice(0.0) {}

    ComputerAssembly(CPU* theCPU, MainMemory* theMainMemory, MotherBoard* theMotherBoard,
        GraphicsCard* theGPU, StorageDevice* theStorage, NetworkCard* theNetwork,
        PowerSupply* thePSU, Battery* theBattery, Case* theCase, double thePrice)
        : myCPU(theCPU), myMainMemory(theMainMemory), myMotherBoard(theMotherBoard), myGraphicsCard(theGPU),
        myStorageDevice(theStorage), myNetworkCard(theNetwork), myPowerSupply(thePSU), myBattery(theBattery),
        myCase(theCase), totalPrice(thePrice) {}

    // Getters
    CPU* getCPU() const { return myCPU; }
    MainMemory* getMainMemory() const { return myMainMemory; }
    MotherBoard* getMotherBoard() const { return myMotherBoard; }
    GraphicsCard* getGraphicsCard() const { return myGraphicsCard; }
    StorageDevice* getStorageDevice() const { return myStorageDevice; }
    NetworkCard* getNetworkCard() const { return myNetworkCard; }
    PowerSupply* getPowerSupply() const { return myPowerSupply; }
    Battery* getBattery() const { return myBattery; }
    Case* getCase() const { return myCase; }
    double getTotalPrice() const { return totalPrice; }

    // Setters
    void setCPU(CPU* theCPU) { myCPU = theCPU; }
    void setMainMemory(MainMemory* theMainMemory) { myMainMemory = theMainMemory; }
    void setMotherBoard(MotherBoard* theMotherBoard) {
        myMotherBoard = theMotherBoard;
    }
    void setGraphicsCard(GraphicsCard* theGraphicsCard) { myGraphicsCard = theGraphicsCard; }
    void setStorageDevice(StorageDevice* theStorageDevice) { myStorageDevice = theStorageDevice; }
    void setNetworkCard(NetworkCard* theNetworkCard) { myNetworkCard = theNetworkCard; }
    void setPowerSupply(PowerSupply* thePSU) { myPowerSupply = thePSU; }
    void setBattery(Battery* theBattery) { myBattery = theBattery; }
    void setCase(Case* theCase) { myCase = theCase; }
    void setTotalPrice(double thePrice) { totalPrice = thePrice; }

};